package com.company.eim.service;

import com.company.eim.model.EimRecord;
import com.company.eim.repository.EimRepository;
import org.springframework.stereotype.Service;

/**
 * Business logic layer for EIM operations.
 * Handles status retrieval with specific business rules.
 */
@Service
public class EimService {

    private static final String NOT_ONBOARDED = "EIMNotOnboarded";

    private final EimRepository eimRepository;

    public EimService(EimRepository eimRepository) {
        this.eimRepository = eimRepository;
    }

    /**
     * Get EIM status by ID.
     * Returns "EIMNotOnboarded" if ID is not found.
     */
    public String getEimStatus(String eimId) {
        return eimRepository.findById(eimId)
            .map(EimRecord::status)
            .orElse(NOT_ONBOARDED);
    }

    /**
     * Check if EIM ID exists in the system
     */
    public boolean isEimOnboarded(String eimId) {
        return eimRepository.existsById(eimId);
    }
}
