package com.company.eim.service;

import com.company.eim.model.EimRecord;
import com.company.eim.repository.EimRepository;
import com.company.eim.service.datasource.EimSource;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Data loader that populates the in-memory repository on application startup.
 * Uses Strategy Pattern via EimSource interface for flexible data source configuration.
 */
@Component
public class DataLoader {

    private static final Logger logger = LoggerFactory.getLogger(DataLoader.class);

    private final EimRepository eimRepository;
    private final EimSource eimSource;

    public DataLoader(EimRepository eimRepository, EimSource eimSource) {
        this.eimRepository = eimRepository;
        this.eimSource = eimSource;
    }

    @PostConstruct
    public void loadData() {
        try {
            logger.info("Starting EIM data load from {} source...", eimSource.getSourceType());

            List<EimRecord> records = eimSource.loadEimRecords();
            eimRepository.saveAll(records);

            logger.info("Successfully loaded {} EIM records into memory", eimRepository.count());

        } catch (Exception e) {
            logger.error("Failed to load EIM data on startup", e);
            throw new RuntimeException("Critical: Unable to initialize EIM data", e);
        }
    }
}
