package com.company.eim.model;

/**
 * Immutable record representing an EIM entity.
 * Uses Java 21 Record feature for concise, immutable data carrier.
 */
public record EimRecord(
    String eimId,
    String status,
    String projectName,
    String type
) {
    /**
     * Compact constructor with validation
     */
    public EimRecord {
        if (eimId == null || eimId.isBlank()) {
            throw new IllegalArgumentException("EIM ID cannot be null or blank");
        }
        if (status == null || status.isBlank()) {
            throw new IllegalArgumentException("Status cannot be null or blank");
        }
    }

    /**
     * Factory method for creating EIM records from CSV row
     */
    public static EimRecord fromCsvRow(String eimId, String status, String projectName, String type) {
        return new EimRecord(
            eimId.trim(),
            status.trim(),
            projectName != null ? projectName.trim() : "",
            type != null ? type.trim() : ""
        );
    }
}
