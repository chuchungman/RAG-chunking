package com.company.eim.controller;

import com.company.eim.service.EimService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * REST Controller for EIM API endpoints.
 * Optimized for low-latency responses with virtual threads support.
 */
@RestController
@RequestMapping("/api/v1/eim")
public class EimController {

    private static final Logger logger = LoggerFactory.getLogger(EimController.class);

    private final EimService eimService;

    public EimController(EimService eimService) {
        this.eimService = eimService;
    }

    /**
     * GET /api/v1/eim/{eimId}
     * Returns the status of the specified EIM ID.
     * Returns "EIMNotOnboarded" if ID is not found (HTTP 200).
     */
    @GetMapping(value = "/{eimId}", produces = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<String> getEimStatus(@PathVariable String eimId) {
        logger.debug("Fetching status for EIM ID: {}", eimId);

        String status = eimService.getEimStatus(eimId);

        return ResponseEntity.ok(status);
    }

    /**
     * Health check endpoint
     */
    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("EIM Service is running");
    }
}
