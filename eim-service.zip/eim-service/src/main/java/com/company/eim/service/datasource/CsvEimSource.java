package com.company.eim.service.datasource;

import com.company.eim.model.EimRecord;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * CSV-based implementation of EimSource.
 * Loads EIM records from a CSV file in the classpath.
 */
@Component
public class CsvEimSource implements EimSource {

    private static final Logger logger = LoggerFactory.getLogger(CsvEimSource.class);

    @Value("classpath:data.csv")
    private Resource csvResource;

    @Override
    public List<EimRecord> loadEimRecords() throws Exception {
        List<EimRecord> records = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(csvResource.getInputStream(), StandardCharsets.UTF_8));
             CSVParser csvParser = new CSVParser(reader, 
                 CSVFormat.DEFAULT
                     .builder()
                     .setHeader()
                     .setSkipHeaderRecord(true)
                     .setIgnoreEmptyLines(true)
                     .setTrim(true)
                     .build())) {

            for (CSVRecord csvRecord : csvParser) {
                try {
                    EimRecord eimRecord = EimRecord.fromCsvRow(
                        csvRecord.get("EimId"),
                        csvRecord.get("Status"),
                        csvRecord.get("ProjectName"),
                        csvRecord.get("Type")
                    );
                    records.add(eimRecord);
                } catch (Exception e) {
                    logger.warn("Skipping invalid CSV row at line {}: {}", 
                        csvRecord.getRecordNumber(), e.getMessage());
                }
            }
        }

        logger.info("Loaded {} EIM records from CSV source", records.size());
        return records;
    }

    @Override
    public String getSourceType() {
        return "CSV";
    }
}
