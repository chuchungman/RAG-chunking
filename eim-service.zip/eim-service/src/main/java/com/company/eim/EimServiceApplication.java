package com.company.eim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main application class for EIM Service.
 * Configured to use Java 21 virtual threads for high-performance request handling.
 */
@SpringBootApplication
public class EimServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(EimServiceApplication.class, args);
    }
}
