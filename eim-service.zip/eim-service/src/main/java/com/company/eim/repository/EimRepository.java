package com.company.eim.repository;

import com.company.eim.model.EimRecord;
import org.springframework.stereotype.Repository;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * In-memory repository for EIM records using ConcurrentHashMap.
 * Thread-safe for concurrent access in high-performance scenarios.
 * Data is ephemeral and lives only as long as the container.
 */
@Repository
public class EimRepository {

    private final Map<String, EimRecord> eimStore = new ConcurrentHashMap<>();

    /**
     * Find EIM record by ID
     */
    public Optional<EimRecord> findById(String eimId) {
        return Optional.ofNullable(eimStore.get(eimId));
    }

    /**
     * Save or update an EIM record
     */
    public void save(EimRecord record) {
        eimStore.put(record.eimId(), record);
    }

    /**
     * Save multiple records (bulk operation)
     */
    public void saveAll(Iterable<EimRecord> records) {
        records.forEach(this::save);
    }

    /**
     * Get total count of records
     */
    public long count() {
        return eimStore.size();
    }

    /**
     * Check if an EIM ID exists
     */
    public boolean existsById(String eimId) {
        return eimStore.containsKey(eimId);
    }

    /**
     * Clear all records (useful for testing/reload)
     */
    public void clear() {
        eimStore.clear();
    }
}
