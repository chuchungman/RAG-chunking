package com.company.eim.service.datasource;

import com.company.eim.model.EimRecord;
import java.util.List;

/**
 * Strategy interface for EIM data source implementations.
 * Allows easy swapping between CSV, REST API, or other data sources.
 */
public interface EimSource {
    /**
     * Load EIM records from the configured source
     * @return List of EIM records
     * @throws Exception if loading fails
     */
    List<EimRecord> loadEimRecords() throws Exception;

    /**
     * Get the name/type of this data source
     */
    String getSourceType();
}
