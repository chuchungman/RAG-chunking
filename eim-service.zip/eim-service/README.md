# EIM Service

A lightweight, high-performance API service for managing EIM (Enterprise Information Management) records.

## Technical Stack

- **Java**: Azul Java 21
- **Framework**: Spring Boot 3.2.5
- **Build Tool**: Gradle 9.2.1
- **Database**: In-Memory (ConcurrentHashMap)
- **Container**: Red Hat UBI 9 with OpenJDK 21

## Features

- Java 21 Virtual Threads for high-performance request handling
- In-memory storage with thread-safe operations
- Strategy Pattern for flexible data source configuration
- Air-gapped deployment ready with Nexus repository
- Production-ready Docker container

## Build Instructions

### Prerequisites
- Gradle 9.2.1 installed locally
- Java 21 (Azul Zulu recommended)
- Docker (for containerization)

### Build the Application

```bash
# Clean and build
gradle clean build

# Build JAR
gradle bootJar
```

### Build Docker Image

```bash
docker build -t eim-service:1.0.0 .
```

### Run the Container

```bash
docker run -d \
  --name eim-service \
  -p 8080:8080 \
  -e JAVA_OPTS="-Xmx512m -Xms256m" \
  eim-service:1.0.0
```

## API Endpoints

### Get EIM Status
```bash
GET /api/v1/eim/{eimId}
```

**Example:**
```bash
curl http://localhost:8080/api/v1/eim/EIM-001
# Response: Active
```

**Not Found:**
```bash
curl http://localhost:8080/api/v1/eim/EIM-999
# Response: EIMNotOnboarded
```

### Health Check
```bash
GET /api/v1/eim/health
```

## Configuration

Edit `src/main/resources/application.properties` to customize:
- Server port
- Logging levels
- Thread pool settings
- Actuator endpoints

## Data Source

The application loads data from `src/main/resources/data.csv` on startup.

### CSV Format
```csv
EimId,Status,ProjectName,Type
EIM-001,Active,Project Alpha,Type A
```

### Future Extension
The `EimSource` interface allows easy swapping to REST API or database sources without changing core logic.

## Performance

- Target: ~10 RPS
- Latency: Sub-millisecond for in-memory lookups
- Scalability: Horizontal scaling ready

## Air-Gapped Deployment

Update `build.gradle` with your internal Nexus repository URL:
```gradle
repositories {
    maven {
        url 'https://nexus.internal.company.com/repository/maven-public/'
    }
}
```

## License

Internal Company Use Only
